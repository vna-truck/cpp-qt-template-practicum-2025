#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDir>
#include <QLabel>
#include <QMainWindow>
#include <prac/QFileDialog>
#include <prac/QTimer>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

enum class Direction {
    kRight,
    kLeft
};

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    virtual ~MainWindow();

    void SetFolder(const QString& d);

    QString GetCurrentFile() const {
        // Получаем список всех файлов директории.
        // Сохраняем в переменную list_files.
        QDir dir(current_folder_);
        auto list_files = dir.entryList();

        int file_index = std::min(cur_file_index_, int(list_files.size()) - 1);
        file_index = std::max(0, file_index);

        return dir.filePath(list_files[file_index]);
    }

private:
    void UpdateImage(const QPixmap& pixmap, int index) {
        if (index < 0) {
            ClearField();
            return;
        }

        files_found_ = true;
        active_pixmap_ = pixmap;
        cur_file_index_ = index;
        FitImage();
    }

    void UpdateEnabled();

    void ClearField();

    QPixmap GetImageByPath(QString path) const {
        QFileInfo file_info(path);
        if (!file_info.isFile()) {
            return {};
        }
        return QPixmap(path);
    }

    std::pair<QPixmap, int> FindNextImage(int start_index, int direction) const;

    void Move(int start_index, int direction) {
        auto result = FindNextImage(start_index, direction);
        UpdateImage(result.first, result.second);
        UpdateEnabled();
    }

    void SetActivePeriod(int period);

private slots:
    void slotNextPicture() {
        Move(cur_file_index_ + 1, 1);
    }

    void on_btn_left_clicked() {
        Move(cur_file_index_ - 1, -1);
        SetActivePeriod(0);
    }
    void on_btn_right_clicked() {
        Move(cur_file_index_ + 1, 1);
        SetActivePeriod(0);
    }

    void slotCustomMenuRequested(QPoint pos);
    void slotUpWindows(bool state);
    void slotUseResources(bool) {
        SetFolder(":/cats/images/");
    }
    void slotChooseDir();

    void slotSetPeriod0sec() {
        SetActivePeriod(0);
    }
    void slotSetPeriod1sec() {
        SetActivePeriod(1000);
    }
    void slotSetPeriod5sec() {
        SetActivePeriod(5000);
    }
    void slotSetPeriod10sec() {
        SetActivePeriod(10000);
    }

private:
    void FitImage();
    void resizeEvent(QResizeEvent *event) override;

private:
    Ui::MainWindow *ui;
    prac::QTimer timer_change_image_;
    QLabel new_lbl_{this};
    QString current_folder_;
    QPixmap active_pixmap_;
    int cur_file_index_ = 0;
    bool files_found_ = false;
};
#endif // MAINWINDOW_H
