#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

QPixmap ResizeImgToFit(const QPixmap &src, int window_width, int window_height) {
    int img_w = src.width();
    int img_h = src.height();

    double w_ratio = double(img_w) / window_width;
    double h_ratio = double(img_h) / window_height;

    QPixmap pix;
    if ( w_ratio < h_ratio ) {
        pix = src.scaledToWidth(window_width);
    } else {
        pix = src.scaledToHeight(window_height);
    }

    return pix;
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    new_lbl_.lower();

    SetFolder(":/cats/images/");

    connect(&timer_change_image_, &prac::QTimer::timeout, this, &MainWindow::slotNextPicture);
    connect(ui->action_up_windows, &QAction::triggered, this, &MainWindow::slotUpWindows);
    connect(ui->action_choose_dir, &QAction::triggered, this, &MainWindow::slotChooseDir);
    connect(ui->action_use_resources, &QAction::triggered, this, &MainWindow::slotUseResources);
    connect(ui->action_0sec, &QAction::triggered, this, &MainWindow::slotSetPeriod0sec);
    connect(ui->action_1sec, &QAction::triggered, this, &MainWindow::slotSetPeriod1sec);
    connect(ui->action_5sec, &QAction::triggered, this, &MainWindow::slotSetPeriod5sec);
    connect(ui->action_10sec, &QAction::triggered, this, &MainWindow::slotSetPeriod10sec);

    ui->menuBar->hide();
    this->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(this, &QMainWindow::customContextMenuRequested, this, &MainWindow::slotCustomMenuRequested);

    slotUpWindows(true);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::SetFolder(const QString &d) {
    current_folder_ = d;

    Move(0, 1);
}

void MainWindow::UpdateEnabled()
{
    ui->btn_left->setEnabled(files_found_);
    ui->btn_right->setEnabled(files_found_);
}

void MainWindow::ClearField() {
    new_lbl_.clear();
    files_found_ = false;
    UpdateEnabled();
}

std::pair<QPixmap, int> MainWindow::FindNextImage(int start_index, int direction) const {
    QDir dir(current_folder_);
    auto file_list = dir.entryList();

    int count = file_list.size();
    int cur_image = start_index;

    for(int steps = 0; steps < count; ++steps, cur_image += direction) {
        cur_image = ((cur_image % count) + count) % count;

        auto pixmap = GetImageByPath(dir.filePath(file_list[cur_image]));
        if (!pixmap.isNull()) {
            return {pixmap, cur_image};
        }
    }
    return {{}, -1};
}

void MainWindow::SetActivePeriod(int period) {
    if (period == 0) {
        timer_change_image_.stop();
    } else {
        timer_change_image_.start(period);
    }

    ui->action_0sec->setChecked(period == 0);
    ui->action_1sec->setChecked(period == 1000);
    ui->action_5sec->setChecked(period == 5000);
    ui->action_10sec->setChecked(period == 10000);
}

void MainWindow::FitImage()
{
    if(active_pixmap_.isNull() || !files_found_) {
        return;
    }

    int win_w = width();
    int win_h = height();

    QPixmap pix = ResizeImgToFit(active_pixmap_, win_w, win_h);

    int new_img_w = pix.width();
    int new_img_h = pix.height();

    new_lbl_.setPixmap( pix );
    new_lbl_.resize(new_img_w, new_img_h);
    new_lbl_.move((win_w - new_img_w) / 2, (win_h - new_img_h) / 2);
}

void MainWindow::resizeEvent(QResizeEvent*)
{
    FitImage();
}

void MainWindow::slotCustomMenuRequested(QPoint pos) {
    ui->menu->popup(this->mapToGlobal(pos));
}

void MainWindow::slotUpWindows(bool state) {
    setWindowFlags(windowFlags().setFlag(Qt::WindowStaysOnTopHint, state));
    show();
}

void MainWindow::slotChooseDir() {
    QString dir = prac::QFileDialog::getExistingDirectory(this,
                        QString("Открыть папку"),
                        QDir::currentPath(),
                        QFileDialog::ShowDirsOnly
                            | QFileDialog::DontResolveSymlinks);
    if(dir.isEmpty()) {
        return;
    }

    SetFolder(dir);
}
