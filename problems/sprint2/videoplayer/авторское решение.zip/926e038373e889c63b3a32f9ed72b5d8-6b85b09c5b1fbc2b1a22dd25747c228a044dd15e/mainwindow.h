#pragma once

#include <QMainWindow>
#include <prac/QTimer>
#include <prac/QMediaPlayer>
#include <prac/QTime>
#include <prac/QDateTime>
#include <QAudioOutput>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private slots:
    void slotOneSecondTick();
    void slotLoadMelody();
    void on_pb_start_stop_clicked();

private:
    int CalculateSecondToAlarm(QDateTime current_time);
    void PlayMelody();
    void UpdateRestSeconds(int time_to_alarm);
    void SetOneSecTimer();
    void Alarm();

private:
    Ui::MainWindow *ui;
    prac::QTimer timer_one_sec_{this};
    QMediaPlayer player_{this};

#if QT_VERSION >= 0x060000
    QAudioOutput audio_output_{this};
#endif

    QDateTime alarm_time_;
    bool is_started_ = false;
    bool is_playing_ = false;
};
