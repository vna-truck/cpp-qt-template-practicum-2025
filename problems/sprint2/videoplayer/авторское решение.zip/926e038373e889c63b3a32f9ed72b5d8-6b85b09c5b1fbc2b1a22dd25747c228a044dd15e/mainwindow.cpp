#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <prac/QFileDialog>
#include <QFileInfo>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    timer_one_sec_.setSingleShot(true);

#if QT_VERSION >= 0x060000
    player_.setAudioOutput(&audio_output_);
    audio_output_.setVolume(100);
#else
    player_.setVolume(100);
#endif

    connect(&timer_one_sec_, &prac::QTimer::timeout, this, &MainWindow::slotOneSecondTick);
    connect(ui->action_load_file, &QAction::triggered, this, &MainWindow::slotLoadMelody);

    prac::QTime now = prac::QTime::currentTime();
    ui->lbl_now->setText(now.toString());

    SetOneSecTimer();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slotOneSecondTick() {
    QDateTime now = QDateTime::currentDateTime();
    ui->lbl_now->setText(now.time().toString());

    if (is_started_ && !is_playing_) {
        int time_to_alarm = CalculateSecondToAlarm(now);
        UpdateRestSeconds(time_to_alarm);

        if (time_to_alarm < 0) {
            Alarm();
        }
    }

    SetOneSecTimer();
}

void MainWindow::slotLoadMelody() {
    QString file_name = QFileDialog::getOpenFileName(this,
                                                    QString::fromUtf8("Открыть файл"),
                                                    QDir::currentPath(),
                                                    "*.wav;*.mp3");
    if(file_name.isEmpty()) {
        return;
    }

    ui->lbl_melody->setText(QFileInfo(file_name).fileName());

#if QT_VERSION >= 0x060000
    player_.setSource(QUrl::fromLocalFile(file_name));
#else
    player_.setMedia(QUrl::fromLocalFile(file_name));
#endif
}

void MainWindow::on_pb_start_stop_clicked()
{
    if (!is_started_) {
        is_started_ = true;
        is_playing_ = false;
        ui->pb_start_stop->setText("Стоп");

        auto now = QDateTime::currentDateTime();

        alarm_time_ = now;
        alarm_time_.setTime(QTime(ui->sb_hour->text().toInt(), ui->sb_min->text().toInt(), ui->sb_sec->text().toInt()));
        if (alarm_time_ < now) {
            alarm_time_ = alarm_time_.addDays(1);
        }

        int time_to_alarm = CalculateSecondToAlarm(now);
        UpdateRestSeconds(time_to_alarm);
    } else {
        is_started_ = false;
        player_.stop();
        ui->pb_start_stop->setText("Старт");
        ui->lbl_timeout->setText("Установите будильник");
    }
}

int MainWindow::CalculateSecondToAlarm(QDateTime current_time) {
    return ((alarm_time_ - current_time).count() + 500) / 1000;
}

void MainWindow::PlayMelody() {
    player_.play();
    is_playing_ = true;
}

void MainWindow::UpdateRestSeconds(int time_to_alarm) {
    QTime zero(0,0,0);
    ui->lbl_timeout->setText(zero.addSecs(time_to_alarm).toString());
}

void MainWindow::Alarm() {
    PlayMelody();
    ui->lbl_timeout->setText("Пора вставать!");
}

void MainWindow::SetOneSecTimer() {
    prac::QTime current_time = prac::QTime::currentTime();
    timer_one_sec_.setInterval(1000 - current_time.msec());
    timer_one_sec_.start();
}
